from scrapy.cmdline import execute
execute('scrapy crawl juzi_spider'.split())