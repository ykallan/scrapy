# -*- coding: utf-8 -*-
import scrapy
import json


class JuziSpiderSpider(scrapy.Spider):
    name = 'juzi_spider'
    allowed_domains = ['itjuzi.com']
    start_url = 'https://www.itjuzi.com/api/closure?com_prov=&sort=&page=%d&keyword=&cat_id='

    def start_requests(self):
        for i in range(1, 629, 1):
            target = self.start_url % i
            yield scrapy.Request(url=target,callback=self.parse)

    def parse(self, response):
        # print(response.status)
        # print(response.text)
        text_dic = json.loads(response.text)
        print(type(text_dic))
        for k,v in text_dic.items():
            print(type(v))
