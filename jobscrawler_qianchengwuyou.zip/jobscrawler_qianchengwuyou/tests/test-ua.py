lis = ['沈阳-沈河区\xa0\xa0', '\xa0\xa0无工作经验\xa0\xa0', '\xa0\xa0大专\xa0\xa0', '\xa0\xa0招10人\xa0\xa0', '\xa0\xa011-21发布']
print(type(lis))
def educations(lis):
    for xueli in lis:
        flag = False
        edu = '空空空'
        if '本科' in xueli:
            edu = '本科'
            flag = True
            if flag:
                return edu
        elif '专科' in xueli:
            edu = '专科'
            flag = True
            if flag:
                return edu
        elif '大专' in xueli:
            edu = '大专'
            flag = True
            if flag:
                return edu
        elif '中专' in xueli:
            edu = '中专'
            flag = True
            if flag:
                return edu
        elif '研究生' in xueli:
            edu = '硕士'
            flag = True
            if flag:
                return edu
        elif '硕士' in xueli:
            edu = '硕士'
            flag = True
            if flag:
                return edu
        elif '博士' in xueli:
            edu = '博士'
            flag = True
            if flag:
                return edu
        elif '博士后' in xueli:
            edu = '博士后'
            flag = True
            if flag:
                return edu
        else:
            edu = '无要求'
            flag = True
            if flag:
                return edu

res = educations(lis)
print(res)