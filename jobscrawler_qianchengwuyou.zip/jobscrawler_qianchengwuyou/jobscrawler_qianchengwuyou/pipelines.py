# -*- coding: utf-8 -*-

import pymysql


class JobscrawlerQianchengwuyouPipeline(object):
    def open_spider(self,spider):
        self.conn = pymysql.Connect(
            host='localhost',
            port=3306,
            user='root',
            passwd='root',
            db='zhaopin',
            charset='utf8',
        )
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        # print('pipelines开始写入')

        sql = '''
        INSERT INTO zhaopin.qiancheng(`job_type`,`job_name`,`job_info`,`job_sal`,`job_benefit`,`exp_require`,`edu_require`,`company_name`,
        `company_industry`,`company_property`,`company_member_num`,`company_profile`,
        `emp_wanted_num`,`releast_time`,`job_url`,`job_loc`) values ("""%s""","""%s""","""%s""","""%s""",
        """%s""","""%s""","""%s""","""%s""","""%s""","""%s""","""%s""","""%s""","""%s""","""%s""","""%s""","""%s""")
        '''
        self.cursor.execute(
            sql%(
                item['job_type'],
                item['job_name'],
                item['job_info'],
                item['job_sal'],
                item['job_benefit'],
                item['exp_require'],
                item['edu_require'],
                item['company_name'],
                item['company_industry'],
                item['company_property'],
                item['company_member_num'],
                item['company_profile'],
                item['emp_wanted_num'],
                item['releast_time'],
                item['job_url'],
                item['job_loc'],
            )
        )
        print('pipelines写入完成')
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()