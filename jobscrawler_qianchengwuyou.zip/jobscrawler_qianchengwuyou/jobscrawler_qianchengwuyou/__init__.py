'''
item['job_type'],item['job_name'],item['job_sal'],item['job_loc'],item['edu_require'],item['exp_require'],
item['lan_require'],item['lan_require'],item['job_benefit'],item['job_info'],item['belong_dep'],
item['proj_require'],item['report_to'] ,item['have_emp'],item['company_name'],item['company_hangye'],
item['company_guimo'],item['company_loc'],item['sing_time'],item['sing_money']
'''
