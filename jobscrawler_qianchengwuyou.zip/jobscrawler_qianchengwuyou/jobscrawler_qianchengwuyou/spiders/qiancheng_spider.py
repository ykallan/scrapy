# -*- coding: utf-8 -*-
import scrapy
from jobscrawler_qianchengwuyou.items import JobscrawlerQianchengwuyouItem
import re


class QianchengSpiderSpider(scrapy.Spider):
    name = 'qiancheng_spider'
    allowed_domains = ['51job.com']
    start_urls = [
        # 数据分析
        'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E6%2595%25B0%25E6%258D%25AE%25E5%2588%2586%25E6%259E%2590,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=',
        # 数据挖掘
        'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E6%2595%25B0%25E6%258D%25AE%25E6%258C%2596%25E6%258E%2598,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=',
        # 算法;
        'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E7%25AE%2597%25E6%25B3%2595,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=',
        # 机器学习
        'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E6%259C%25BA%25E5%2599%25A8%25E5%25AD%25A6%25E4%25B9%25A0,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=',
        # 深度学习
        'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E6%25B7%25B1%25E5%25BA%25A6%25E5%25AD%25A6%25E4%25B9%25A0,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=',
        # 人工智能
        'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E4%25BA%25BA%25E5%25B7%25A5%25E6%2599%25BA%25E8%2583%25BD,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=',
                  ]
    def open_spider(self):
        self.job_types = ''

    def parse(self, response):
        # print('响应码：'+str(response.status))
        # print('响应中返回的代理ip：'+response.meta['proxy'])
        page_num = response.xpath('//div[@class="p_in"]/ul/li[@class="on"]/text()').extract_first()
        shujufenxi = 'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E6%2595%25B0%25E6%258D%25AE%25E5%2588%2586%25E6%259E%2590,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare='
        shujuwajue = 'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E6%2595%25B0%25E6%258D%25AE%25E6%258C%2596%25E6%258E%2598,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare='
        suanfa = 'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E7%25AE%2597%25E6%25B3%2595,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare='
        jiqixuexi = 'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E6%259C%25BA%25E5%2599%25A8%25E5%25AD%25A6%25E4%25B9%25A0,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare='
        shenduxuexi = 'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E6%25B7%25B1%25E5%25BA%25A6%25E5%25AD%25A6%25E4%25B9%25A0,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare='
        rengongzhineng = 'https://search.51job.com/list/000000,000000,0000,00,9,99,%25E4%25BA%25BA%25E5%25B7%25A5%25E6%2599%25BA%25E8%2583%25BD,2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare='
        target = response.url
        if target == shujufenxi:
            self.job_types = '数据分析'
        if target == shujuwajue:
            self.job_types = '数据挖掘'
        if target == suanfa:
            self.job_types = '算法'
        if target == jiqixuexi:
            self.job_types = '机器学习'
        if target == shenduxuexi:
            self.job_types = '深度学习'
        if target == rengongzhineng:
            self.job_types = '人工智能'

        el_urls = response.xpath('//p[@class="t1 "]/span/a/@href').extract()
        for el_url in el_urls:
            yield scrapy.Request(url=el_url, callback=self.detail_parse, meta={'job_typer': self.job_types,'page_num': page_num} )
        next_page = response.xpath('//li[@class="bk"][2]/a/@href').extract_first()


        yield scrapy.Request(url=next_page, callback=self.parse,meta={'job_type':self.job_types})

    def detail_parse(self,response):
        # print('进入detail_parse')
        item = JobscrawlerQianchengwuyouItem()
        print(response.meta['job_typer'])

        item['job_name'] = response.xpath('//div[@class="cn"]/h1/text()').extract_first()  # 1招聘名称
        # print('job_name'+item['job_name'])
        item['job_type'] = response.meta['job_typer']
        page_num = response.meta['page_num']
        print(item['job_type']+'第'+page_num+'页')
        job_info = response.xpath('//div[@class="bmsg job_msg inbox"]//*/text()').extract()  # 2职位信息 岗位职责
        job_info_text = ''
        for idx, job in enumerate(job_info):
            job_info[idx] = job.strip()
            job_info[idx] = job_info[idx].replace("\'\\r\'",'')
            job_info[idx] = job_info[idx].replace("\'\\n\'", '')
            job_info[idx] = job_info[idx].replace("\'\\t\'", '')
            job_info[idx] = job_info[idx].replace("\'\\b\'", '')
            if len(job_info[idx]) == 0:
                job_info.remove(job_info[idx])
        for i in job_info:
            job_info_text += i
        item['job_info'] = job_info_text

        item['job_sal'] =response.xpath('//div[@class="cn"]/strong/text()').extract_first()  # 3 薪资
        item['job_benefit'] =response.xpath('//span[@class="sp4"]/text()').extract()  # 4 职位福利
        # 5 经验要求 任职资格
        exp_requires = response.xpath('//div[@class="bmsg job_msg inbox"]/*/text()').extract()
        for exp_require in exp_requires:
            exp_require_text = ''.join(exp_require)
        item['exp_require'] =  exp_require_text
        xuelis = response.xpath('//p[@class="msg ltype"]/text()').extract()  # 6 学历要求
        # print(xuelis)
        item['edu_require'] = '无要求'
        for xueli in xuelis:
            if '本科' in xueli:
                item['edu_require'] ='本科'
            if '专科' in xueli:
                item['edu_require'] = '专科'
            if '大专' in xueli:
                item['edu_require'] = '大专'
            if '中专' in xueli:
                item['edu_require'] = '中专'
            if '研究生' in xueli:
                item['edu_require'] = '硕士'
            if '硕士' in xueli:
                item['edu_require'] = '硕士'
            if '博士' in xueli:
                item['edu_require'] = '博士'
            if '博士后' in xueli:
                item['edu_require'] = '博士后'

        item['company_name'] = response.xpath('//p[@class="cname"]/a[1]/@title').extract_first()  # 7公司名称
        item['company_industry'] = response.xpath('//div[@class="com_tag"]/p[3]/@title').extract_first()  # 8 公司行业
        item['company_property'] = response.xpath('//div[@class="com_tag"]/p[1]/@title').extract_first()  # 9 公司性质
        item['company_member_num'] = response.xpath('//div[@class="com_tag"]/p[2]/@title').extract_first()  # 10 公司人数
        item['company_profile'] = response.xpath('//div[@class="tmsg inbox"]/text()').extract_first()  # 11 公司概况
        # 12 招聘人数
        msg_ltype_list = response.xpath('//p[@class="msg ltype"]/text()').extract()
        for msg in msg_ltype_list:
            if re.search('招', msg):
                item['emp_wanted_num'] = msg.split()[0]
        releast_time = response.xpath('//p[@class="msg ltype"]/text()').extract()[-1][0:-2].strip().replace('-','月')   # 13 发布时间
        item['releast_time']=releast_time
        item['job_url'] = 'qwerty'  # 14 职位链接
        item['job_loc'] = response.xpath('//p[@class="msg ltype"]/text()').extract_first()
        yield item
        return item
