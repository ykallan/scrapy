from scrapy.cmdline import execute
execute('scrapy crawl qiancheng_spider -o qianchengwuyou.csv'.split())