# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy

class JobscrawlerQianchengwuyouItem(scrapy.Item):
    job_type = scrapy.Field()  # 数据分析,数据挖掘,人工智能等
    job_name = scrapy.Field()  # 1招聘名称
    job_info = scrapy.Field()  # 2职位信息
    job_sal = scrapy.Field()  # 3薪资
    job_benefit = scrapy.Field()  # 4职位福利
    exp_require = scrapy.Field()  # 5经验要求
    edu_require = scrapy.Field()  # 6学历要求
    company_name = scrapy.Field()  # 7公司名称
    company_industry = scrapy.Field()  # 8公司行业
    company_property = scrapy.Field()  # 9公司性质
    company_member_num = scrapy.Field()  # 10公司人数
    company_profile = scrapy.Field()  # 11公司概况
    emp_wanted_num= scrapy.Field()  # 12招聘人数
    releast_time = scrapy.Field()  # 13发布时间
    job_url = scrapy.Field()  # 14职位链接
    job_loc = scrapy.Field()  # 15工作地址


