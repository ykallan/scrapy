import time
import requests
from lxml import etree
import random
import redis
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',
    'Cookie': '__cfduid=d6092af0a263ce2770d0bfe3b337642e31574828718; Hm_lvt_526caf4e20c21f06a4e9209712d6a20e=1575252916,1575461604,1575467027,1575506430; zkhanecookieclassrecord=%2C54%2C53%2C; security_session_verify=869fa8fc1b76104056bac16542d08ab4; Hm_lpvt_526caf4e20c21f06a4e9209712d6a20e=1575506712',
    'Upgrade-Insecure-Requests': '1',
}
start_url = 'http://pic.netbian.com/4kfengjing/'
base_url = 'http://pic.netbian.com'

r = redis.Redis(host='localhost', port=6379)


# 发起请求，获取每个分类的url
def start_request():
    response = requests.get(url=start_url,headers=headers)
    response.encoding='gbk'
    html = etree.HTML(response.content)
    type_urls = html.xpath('//div[@class="classify clearfix"]/a/@href')
    type_names = html.xpath('//div[@class="classify clearfix"]/a/text()')
    for idx,type_url in enumerate(type_urls):
        type_parse(base_url+type_url,type_names[idx])


# 对每个类别进行请求，如果有下一页，继续循环此请求
def type_parse(url,type_name):
    response = requests.get(url=url, headers=headers)
    response.encoding='gbk'
    html = etree.HTML(response.content)
    pic_urls = html.xpath('//ul[@class="clearfix"]/li/a/@href')
    for pic_url in pic_urls:
        result = r.get(base_url+pic_url)
        if not result:
            get_img(base_url+pic_url,type_name)
    time.sleep(random.random())
    next_page = html.xpath('//div[@class="page"]/a')[-1]
    next_page_text = next_page.xpath('.//text()')[0]
    next_url = next_page.xpath('.//@href')[0]
    if next_page_text == '下一页':
        type_parse(base_url+next_url,type_name)


# 获取图片
def get_img(url,type_name):
    response = requests.get(url=url, headers=headers)
    response.encoding = 'gbk'
    html = etree.HTML(response.content)
    pic = html.xpath('//a[@id="img"]/img/@src')[0]
    pic_name = pic.split('/')[-1]
    pic_data = requests.get(url=base_url+pic,headers=headers)
    with open('./pic/%s%s'%(str(type_name),pic_name),'wb') as f:
        f.write(pic_data.content)
    r.set(base_url+url,'ok')
    print('保存完成，写入数据库完成')


def main():
    start_request()
    r.close()


if __name__ == '__main__':
    main()
