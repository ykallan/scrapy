# -*- coding: utf-8 -*-
import scrapy
from ..items import FlightcrawlXiechengItem
import time


class XiechengSpider(scrapy.Spider):
    name = 'xiecheng'
    allowed_domains = ['ctrip.com']
    start_urls = ['https://flights.ctrip.com/schedule/']

    def start_requests(self):
        for start_url in self.start_urls:
            yield scrapy.Request(url=start_url,callback=self.parse)

    # 解析国内城市出发航班时刻
    def parse(self, response):
        add_urls = response.xpath('//ul[@class="letter_list"]/li/div/a/@href').extract()
        for add_url in add_urls:
            detail_add_url = response.urljoin(add_url)
            yield scrapy.Request(url=detail_add_url, callback=self.add_parse)

    # 某个城市出发到另一个地区的页面
    def add_parse(self,response):
        fly_to_add_urls = response.xpath('//ul[@class="letter_list"]/li/div/a/@href').extract()
        for fly_to_add_url in fly_to_add_urls:
            yield scrapy.Request(url=fly_to_add_url,callback=self.flight_detail)

    # 最终的航班详情页
    # 出发地到目的站的所有航班信息
    def flight_detail(self,response):
        print('进入flight_detail')
        item = FlightcrawlXiechengItem()
        line_name = response.xpath('//h4[@class="result_type"]/text()').extract_first()
        lin_nums = response.xpath('//tr[@data-defer="form"]').extract()
        if len(lin_nums) > 0:
            flight_companys = response.xpath('//tr[@data-defer="form"]/td[@class="flight_logo"]/a/strong/@data-description').extract()
            flight_codes = response.xpath('//tr[@data-defer="form"]/td[@class="flight_logo"]/a/strong/text()').extract()

            #解析需要的信息添加到item中即可

            for i in range(0,len(lin_nums),1):
                item['line_name'] = line_name
                item['flight_company'] = flight_companys[i]
                item['flight_code'] = flight_codes[i]
                print(item['line_name'],item['flight_company'],item['flight_code'])
                yield item
                return item