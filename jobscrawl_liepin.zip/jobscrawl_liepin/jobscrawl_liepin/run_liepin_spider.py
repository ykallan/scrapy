from scrapy.cmdline import execute
# execute('scrapy crawl liepin_spider'.split())
execute('scrapy crawl liepin_spider -o liepin.csv'.split())