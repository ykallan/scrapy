# -*- coding: utf-8 -*-
import pymysql


class JobscrawlLiepinPipeline(object):

    def open_spider(self,spider):
        self.conn = pymysql.Connect(
            host='localhost',
            port=3306,
            user='root',
            passwd='root',
            db='zhaopin',
            charset='utf8',
        )
        self.cursor = self.conn.cursor()


    def process_item(self, item, spider):
        # print('pipelines开始写入')
        sql = '''
         INSERT INTO zhaopin.liepin(`job_type`,`job_name`,`job_sal`,`job_loc`,`edu_require`,
         `exp_require`,`lan_require`,`age_require`,`job_benefit`,`job_info`,
         `belong_dep`,`proj_require`,`report_to`,`have_emp`,`company_name`,
         `company_hangye`,`company_guimo`,`company_loc`,`sing_time`,`sing_money`,) 
         values ("""%s""","""%s""","""%s""","""%s""","""%s""",
                 """%s""","""%s""","""%s""","""%s""","""%s""",
                 """%s""","""%s""","""%s""","""%s""","""%s""",
                 """%s""","""%s""","""%s""","""%s""","""%s""")
         '''
        self.cursor.execute(
            sql % (
                item['job_type'], item['job_name'],
                item['job_sal'], item['job_loc'],
                item['edu_require'],item['exp_require'],
                item['lan_require'], item['age_require'],
                item['job_benefit'], item['job_info'],
                item['belong_dep'],item['proj_require'],
                item['report_to'], item['have_emp'],
                item['company_name'], item['company_hangye'],
                item['company_guimo'], item['company_loc'],
                item['sing_time'], item['sing_money']
            )
        )
        print('pipelines写入完成')
        self.conn.commit()
        return item

    def close_spider(self):
        self.cursor.close()
        self.conn.close()
