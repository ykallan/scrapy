# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class JobscrawlLiepinItem(scrapy.Item):
    # 职位相关
    job_type = scrapy.Field()  # 1数据分析,数据挖掘,人工智能等
    job_name = scrapy.Field()  # 2招聘名称
    job_sal = scrapy.Field()  # 3薪资
    job_loc = scrapy.Field()  # 4工作地址
    edu_require = scrapy.Field()  # 5学历要求
    exp_require = scrapy.Field()  # 6经验要求
    lan_require = scrapy.Field()  # 7语言要求
    age_require = scrapy.Field()  # 8年龄要求
    job_benefit = scrapy.Field()  # 9职位福利 五险一金啥的
    job_info = scrapy.Field()  # 10职位信息
    belong_dep = scrapy.Field()  # 11所属部门
    proj_require = scrapy.Field()  # 12专业要求
    report_to = scrapy.Field()  # 13汇报对象
    have_emp = scrapy.Field()  # 14下属人
    # 公司相关
    company_name = scrapy.Field()  # 15公司名称
    company_hangye = scrapy.Field()  # 16公司行业
    company_guimo = scrapy.Field()  # 17公司规模
    company_loc = scrapy.Field()  # 18公司地址
    sing_time= scrapy.Field()  # 19注册时间
    sing_money = scrapy.Field()  # 20注册资本
