# -*- coding: utf-8 -*-
import scrapy
from ..items import JobscrawlLiepinItem


class LiepinSpiderSpider(scrapy.Spider):
    name = 'liepin_spider'
    allowed_domains = ['liepin.com']
    start_urls = ['http://liepin.com/']

    def __init__(self):
        self.base_url = 'https://www.liepin.com/zhaopin/?industries=&subIndustry=&dqs=&salary=&jobKind=&pubTime=&compkind=&compscale=&industryType=&searchType=1&clean_condition=&isAnalysis=&init=1&sortFlag=15&flushckid=0&fromSearchBtn=1&headckid=4db2a2a1d8ae52e9&d_headId=4cb9bc9c03dee4d1fc19e06d71221597&d_ckId=4cb9bc9c03dee4d1fc19e06d71221597&d_sfrom=search_fp&d_curPage=99&d_pageSize=40&siTag=8Gjw2tdHib7iEBY8QKS1DQ~fA9rXquZc5IkJpXC-Ycixw&key='

    # 对6种岗位类型分别发起请求
    def start_requests(self):
        start_lists = ['数据分析','数据挖掘','算法','机器学习','深度学习','人工智能']
        for key_word in start_lists:
            target_url = self.base_url+key_word
            yield scrapy.Request(url=target_url, meta={'key_word':key_word})

    # 爬取企业招聘的数据，急聘与猎头的暂时不考虑
    def parse(self,response):
        key_word = response.meta['key_word']  # 1数据分析,数据挖掘,人工智能等
        url_lists = response.xpath('//div[@class="job-info"]/h3/a/@href').extract()
        job_lis_type = response.xpath('//*/i/b/text()').extract()
        target_for_detail_urls = enumerate(zip(url_lists,job_lis_type))

        # 针对企业招聘与急聘，做出两种不同的判断提取条件
        # 只爬取企业招聘
        for idx,target_for_detail_url in target_for_detail_urls:
            if target_for_detail_url[0][0:5]=='https':
                if target_for_detail_url[1]=='企':
                    yield scrapy.Request(url=target_for_detail_url[0], callback=self.detail_parse_qi, meta={'key_word': key_word})

        # 获取下一页，循环执行parse
        next_page = response.xpath('//span[@class="ellipsis"]/following-sibling::a[1]/@href').extract_first()
        next_page = 'https://www.liepin.com'+next_page
        yield scrapy.Request(url=next_page, callback=self.parse, meta={'key_word': key_word})

    # 企业招聘
    def detail_parse_qi(self,response):
        job_benefit_text = ''
        job_info_text = ''
        print('进入detail_parse_qi')
        item = JobscrawlLiepinItem()
        item['job_type'] = response.meta['key_word']  # 1数据分析,数据挖掘,人工智能等
        item['job_name'] = response.xpath('//h1/text()').extract_first().strip().replace('\\','')  # 2招聘名称
        item['job_sal'] = response.xpath('//p[@class="job-item-title"]/text()').extract_first().strip().replace('·','，')   # 3薪资
        item['job_loc'] = response.xpath('//p[@class="basic-infor"]/span/a/text()').extract_first().strip().replace('\'','')   # 4工作地址
        item['edu_require'] = response.xpath(
            '//div[@class="job-qualifications"]/span[1]/text()').extract_first()  # 5学历要求
        item['exp_require'] = response.xpath(
            '//div[@class="job-qualifications"]/span[2]/text()').extract_first()  # 6经验要求
        item['lan_require'] = response.xpath(
            '//div[@class="job-qualifications"]/span[3]/text()').extract_first()  # 7语言要求
        item['age_require'] = response.xpath(
            '//div[@class="job-qualifications"]/span[4]/text()').extract_first()  # 8年龄要求
        # 以上ok

        job_benefits = response.xpath('//ul[@class="comp-tag-list clearfix"]/li/span/text()').extract()  # 9职位福利 五险一金啥的
        # print(job_benefits)
        for idx,job_benefit in enumerate(job_benefits):
            job_benefit_text += job_benefit
            if idx != -1:
                job_benefit_text += '，'
        job_benefit_text = job_benefit_text[0:-1]
        item['job_benefit'] = job_benefit_text
        if len(job_benefits) == 0:
            item['job_benefit'] = '此职位暂时没有填写福利待遇'
        # 以上ok
        job_infos = response.xpath('//div[@class="job-item main-message job-description"]/div[@class="content content-word"]/text()').extract()  # 10职位信息

        for job_info in job_infos:
            job_info_text += job_info.replace('\\xa0','')
        item['job_info'] = job_info_text
        if len(job_infos) == 0:
            item['job_info'] = '此岗位可能暂时没有填写任何岗位任职要求'
        # ok
        item['belong_dep'] = response.xpath('//div[@class="content"]/ul/li[1]/label/text()').extract_first()  # 11所属部门
        item['proj_require'] = response.xpath('//div[@class="content"]/ul/li[2]/label/text()').extract_first()  # 12专业要求
        item['report_to'] = response.xpath('//div[@class="content"]/ul/li[3]/label/text()').extract_first()  # 13汇报对象
        item['have_emp'] = response.xpath('//div[@class="content"]/ul/li[4]/label/text()').extract_first()  # 14下属人数
        # ok
        item['company_name'] = response.xpath('//div[@class="new-compwrap"]/div[@class="company-logo"]/p/a/text()').extract_first()  # 15公司名称
        item['company_hangye'] = '行业：'+response.xpath(
            '//div[@class="new-compwrap"]/ul[@class="new-compintro"]/li/a/text()').extract_first()  # 16公司行业
        item['company_guimo'] = response.xpath(
            '//div[@class="new-compwrap"]/ul[@class="new-compintro"]/li[2]/text()').extract_first()  # 17公司规模
        item['company_loc'] = response.xpath(
            '//div[@class="new-compwrap"]/ul[@class="new-compintro"]/li[3]/text()').extract_first()  # 18公司地址
        # ok
        '''
            sing_time= scrapy.Field()  # 19注册时间
            sing_money = scrapy.Field()  # 20注册资本
        '''
        item['sing_time'] = response.xpath('//ul[@class="new-compdetail"]/li[1]/text()').extract_first()  # 19注册时间
        item['sing_money'] = response.xpath('//ul[@class="new-compdetail"]/li[2]/text()').extract_first()  # 20注册资本
        '''print(item['job_type'], item['job_name'],
                item['job_sal'], item['job_loc'],
                item['edu_require'],item['exp_require'],
                item['lan_require'], item['age_require'],
                item['job_benefit'], item['job_info'],
                item['belong_dep'],item['proj_require'],
                item['report_to'], item['have_emp'],
                item['company_name'], item['company_hangye'],
                item['company_guimo'], item['company_loc'],
                item['sing_time'], item['sing_money'])
        '''
        yield item
        return item
