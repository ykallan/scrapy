from scrapy.cmdline import execute
execute(['scrapy','crawl','kuaidl','-o','kuaidaili.csv'])
