# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class KuaidailiItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass
    ip = scrapy.Field()
    prot = scrapy.Field()
    niming = scrapy.Field()
    leixing = scrapy.Field()
    weizhi = scrapy.Field()
    xiangying = scrapy.Field()
    yanzheng = scrapy.Field()
    laiyuan = scrapy.Field()
    gongyingshang = scrapy.Field()
