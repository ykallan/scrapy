# -*- coding: utf-8 -*-
import scrapy
from kuaidaili.items import KuaidailiItem
import redis

class KuaidlSpider(scrapy.Spider):
    name = 'kuaidl'
    allowed_domains = ['kuaidaili.com']
    # start_urls = ['https://www.kuaidaili.com/free/']
    # https://www.kuaidaili.com/free/intr/
    start_urls = ['https://www.kuaidaili.com/free/intr/']
    laiyuan = '快代理'
    def __init__(self):
        pass
        self.r = redis.Redis('localhost',6379)

    def parse(self, response):
        ips = response.xpath('//tbody/tr/td[1]/text()').extract()
        prots = response.xpath('//tbody/tr/td[2]/text()').extract()
        nimings = response.xpath('//tbody/tr/td[3]/text()').extract()
        leixings = response.xpath('//tbody/tr/td[4]/text()').extract()
        weizhis = response.xpath('//tbody/tr/td[5]/text()').extract()
        xiangyings = response.xpath('//tbody/tr/td[6]/text()').extract()
        yanzhengs = response.xpath('//tbody/tr/td[7]/text()').extract()
        item = KuaidailiItem()
        for length in range(len(ips)):
            item['ip'] = ips[length]
            item['prot'] = prots[length]
            item['niming'] = nimings[length]
            item['leixing'] = leixings[length]
            item['weizhi'] = weizhis[length].split(' ')[0:-2]
            item['xiangying'] = xiangyings[length]
            item['yanzheng'] = yanzhengs[length]
            item['laiyuan'] = self.laiyuan
            item['gongyingshang'] = weizhis[length].split(' ')[-1]

            yield item

        max_page = response.xpath('//div[@id="listnav"]/ul/li[last()-1]/a/text()').extract_first()

        for i in range(2,int(max_page)):
            # next_url = 'https://www.kuaidaili.com/free/inha/{}/'.format(i)
            next_url = 'https://www.kuaidaili.com/free/intr/{}/'.format(i)
            if not self.r.get(next_url):
                yield scrapy.Request(url=next_url,callback=self.parse_next_page)

    def parse_next_page(self,response):
        ips = response.xpath('//tbody/tr/td[1]/text()').extract()
        prots = response.xpath('//tbody/tr/td[2]/text()').extract()
        nimings = response.xpath('//tbody/tr/td[3]/text()').extract()
        leixings = response.xpath('//tbody/tr/td[4]/text()').extract()
        weizhis = response.xpath('//tbody/tr/td[5]/text()').extract()
        xiangyings = response.xpath('//tbody/tr/td[6]/text()').extract()
        yanzhengs = response.xpath('//tbody/tr/td[7]/text()').extract()
        item = KuaidailiItem()
        for length in range(len(ips)):
            item['ip'] = ips[length]
            item['prot'] = prots[length]
            item['niming'] = nimings[length]
            item['leixing'] = leixings[length]
            item['weizhi'] = weizhis[length].split(' ')[0:-2]
            item['xiangying'] = xiangyings[length]
            item['yanzheng'] = yanzhengs[length]
            item['laiyuan'] = self.laiyuan
            item['gongyingshang'] = weizhis[length].split(' ')[-1]

            yield item
        self.r.set(response.url,'ok')