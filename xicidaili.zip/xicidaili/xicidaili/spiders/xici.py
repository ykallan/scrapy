# -*- coding: utf-8 -*-
import scrapy
from xicidaili.items import XicidailiItem
import redis

class XiciSpider(scrapy.Spider):
    name = 'xici'
    allowed_domains = ['xicidaili.com']
    start_urls = ['https://www.xicidaili.com/nn/']

    def __init__(self):
        super(XiciSpider, self).__init__()
        self.r = redis.Redis('localhost', 6379)

    def parse(self, response):
        ips = response.xpath('//tr/td[2]/text()').extract()
        ports = response.xpath('//tr/td[3]/text()').extract()
        nimings = response.xpath('//tr/td[5]/text()').extract()
        leixings = response.xpath('//tr/td[6]/text()').extract()
        cunhuos = response.xpath('//tr/td[9]/text()').extract()
        yanzhengs = response.xpath('//tr/td[10]/text()').extract()
        item = XicidailiItem()
        for i in range(len(ips)):
            item['ip'] = ips[i]
            item['port'] = ports[i]
            item['niming'] = nimings[i]
            item['leixing'] = leixings[i]
            item['cunhuo'] = cunhuos[i]
            item['yanzheng'] = yanzhengs[i]
            item['laiyuan'] = '西次代理'
            yield item

        for page in range(2, 4047):
            next_url = self.start_urls[0]+str(page)
            if not self.r.get(next_url):
                yield scrapy.Request(url=next_url, callback=self.next_page)

    def next_page(self,response):
        ips = response.xpath('//tr/td[2]/text()').extract()
        ports = response.xpath('//tr/td[3]/text()').extract()
        nimings = response.xpath('//tr/td[5]/text()').extract()
        leixings = response.xpath('//tr/td[6]/text()').extract()
        cunhuos = response.xpath('//tr/td[9]/text()').extract()
        yanzhengs = response.xpath('//tr/td[10]/text()').extract()
        item = XicidailiItem()

        for i in range(len(ips)):
            item['ip'] = ips[i]
            item['port'] = ports[i]
            item['niming'] = nimings[i]
            item['leixing'] = leixings[i]
            item['cunhuo'] = cunhuos[i]
            item['yanzheng'] = yanzhengs[i]
            item['laiyuan'] = '西次代理'
            yield item
        # self.r.set(response.url,'ok')
        pass
